import portfolioDataRaw from '/data/chats/pbwzp/workspace/portfolio_data.json';

// Export the portfolio data for use across components
export const portfolioData = portfolioDataRaw;